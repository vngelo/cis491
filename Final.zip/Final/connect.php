<?php>
require "config.php";
$connection = new PDO("mysql:host=$host", $username, $password, $options);
